import type { Dispatch, SetStateAction } from "react";

export type SetStateActionType<T> = Dispatch<SetStateAction<T>>;
